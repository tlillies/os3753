Analysis of Linux schedulers running different types of programs

To run just "sudo ./testscript"

To collect all data into one file run "python collection.py"