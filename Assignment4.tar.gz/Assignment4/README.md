Analysis of Linux schedulers running different types of programs
